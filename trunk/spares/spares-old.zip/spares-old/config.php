<?php

// Common
$tmp_dir = "c:\\tmp";
$dir_delimiter = "\\";

// DataBases
// -- TecDoc DB
$dbserv = "localhost";
$dbname = "tecdoc";
$dbuser = "root";
$dbpass = "";
//
// -- Stock DB
$stock_owner_id = 1001;
$stock_serv = "localhost";
$stock_base = "test";
$stock_user = "root";
$stock_pass = "";

// Graphics
$img_dir = "e:\\tecdoc_img";
$err_file = "c:\\tmp\\wizard.jpg";
$convertor = "c:\\bin\\imagick\\convert";

// TecDoc defaults
$country_code = 223;
?>