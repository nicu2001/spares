<?
$data_host = 'http://omega.dnsd.me';
$data_script = '/spares/getimg.php';

// Проверка корректности протокола
$doc_ext = 'jpeg';
if( !isset($_REQUEST['id']) || !is_numeric($_REQUEST['id']) || (int)$_REQUEST['id'] == 0 ||
    !isset($_REQUEST['photo']) || $_REQUEST['photo'] == '')
    exit(0);
        
$full_req = $data_host.$data_script.'?id='.$_REQUEST['id'].'&photo='.$_REQUEST['photo'];

$result = file_get_contents($full_req);
if( $result === false ) 
	$result = "";

//header("Content-Type: image/".$doc_ext); 
echo $result;
?>
