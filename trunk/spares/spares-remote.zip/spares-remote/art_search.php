<?
$data_host = 'http://omega.dnsd.me';
$data_script = '/spares/art_search.php';

if( !check_ajax_referer() ) {
    header( 'Location: index.php' );
    exit(0);
}

$errmess = '';
while( true ){

// Проверка корректности протокола

    if( !isset($_REQUEST['oper']) || ( $oper = strip_tags(trim($_REQUEST['oper']))) != 'search_articles' ||
        !isset($_REQUEST['art_code']) || ( $art = strip_tags(trim($_REQUEST['art_code']))) == '' || 
		!isset($_REQUEST['doing']) )
    {
        $errmess = "Нарушение протокола";
        break;
    }
    
	$postdata = http_build_query(
		array( 'oper' => 'search_articles', 'art_code' => $art,	'doing' => '' )
	);

	$opts = array('http' =>
		array(
			'method'  => 'POST',
			'header'  => array(
						'Content-type: application/x-www-form-urlencoded',
						'Referer: '.$data_host."/",
						'X-Requested-With: XMLHttpRequest'
						),
			'content' => $postdata
		)
	);

	$context = stream_context_create($opts);
	$result = file_get_contents($data_host.$data_script, false, $context);
	if( $result === false ) 
		$errmess = "Ошибка получения данных";

    break;
}
if( $errmess != '' ) {
    echo_json_answer( 1, $errmess );
}
else {
    header("Content-type: text/script;charset=utf-8");
    echo $result;   
}    
exit(0);


function check_ajax_referer() {
 return ( preg_match("|^http(s)?://".$_SERVER['SERVER_NAME']."/|", $_SERVER['HTTP_REFERER']) &&
            isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ) ? true : false;
}

function echo_json_answer( $errcode, $errmess ) {
    $json_arr = array( 
        'errcode'=>$errcode, 
        'errmess'=>$errmess 
    );
    header("Content-type: text/script;charset=utf-8");
    echo json_encode( $json_arr );   
}
?>
