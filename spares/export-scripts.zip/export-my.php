<?php
//
// Почти оригинальный скрипт экспорта баз. 
// Очень медленно работает
//

class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $mysql_serv = "localhost";
var $mysql_login = "root";
var $mysql_pass = "";
var $mysql_db = "tecdoc";
var $odbc_serv = "localhost";
var $odbc_login = "tecdoc";
var $odbc_pass = "tcd_error_0";
var $odbc_db = "TECDOC_CD_2_2011";
var $odbc_driver = "Transbase ODBC TECDOC CD 2_2011";
var $odbc_id = "";

const DEBUG = false;
const DEBUG_MAX = 100;

function odbcConnect() {
	$constr = "Driver={" . $this->odbc_driver . "};Database=" . $this->odbc_db . "@" . $this->odbc_serv;
	$this->odbc_id = odbc_connect($constr, $this->odbc_login, $this->odbc_pass);
	odbc_autocommit($this->odbc_id, TRUE);
}

function mysqlConnect() {
	mysql_connect($this->mysql_serv, $this->mysql_login, $this->mysql_pass);
	mysql_select_db($this->mysql_db);
// 'cp1251'(Windows) 'utf8'(Unix)
	mysql_set_charset("cp1251");
}

function exportFromTransbase($table_name) {

	print Tools::utf2oem(str_pad($table_name, 32) );

	$odbc_query = "SELECT * FROM " . $table_name;

	$data = odbc_exec($this->odbc_id, $odbc_query);
	odbc_longreadlen($data, 10485760);

	$i = 1;
	
// Tag: 01
	mysql_query("LOCK TABLES ".$table_name." WRITE");
	while($row = odbc_fetch_array($data))
	{
		foreach($row as $key => $value) {
			$keys[] = "`" . $key . "`";
			$values[] = "'" . mysql_real_escape_string($value) . "'";
		}

		$mysql_query = "INSERT INTO `" . $table_name . "` (" . implode(",", $keys) . ") VALUES (" . implode(",", $values) . ")";
		if( !mysql_query($mysql_query) ) {
			mysql_query("UNLOCK TABLES");
			die( "Error. Record: ".$i."\n" );
		}
		set_time_limit(3600);
		unset($keys);
		unset($values);
		unset($row);

		$i++;
		if( self::DEBUG  && $i > self::DEBUG_MAX ) break;
	}
	echo ($i-1)."\n";
	mysql_query("UNLOCK TABLES");
}

function TB_TableList() {
	$tabs = odbc_tables($this->odbc_id);
	$TB_Tables = array();
	while (odbc_fetch_row($tabs)){
		if (odbc_result($tabs, "TABLE_TYPE") == "TABLE") {
			$table_name = odbc_result($tabs, "TABLE_NAME");
			if(strstr($table_name, "TOF_")) {
				if(!strstr($table_name, "TOF_GRA_DATA")) {
					$TB_Tables[] = $table_name;
				}
			}
		}
	}
return $TB_Tables;
}

function My_TableList() {
	$tabs = mysql_query("SHOW TABLES FROM ".$this->mysql_db);
	$My_Tables = array();
	while ($row = mysql_fetch_row($tabs)){
		$My_Tables[] = $row[0];
	}
	mysql_free_result($tabs);
return $My_Tables;
}

function Show_Diff( $tb_tab, $my_tab ) {
	echo "TransBase:".count($tb_tab)."  MySQL:".count($my_tab)."\n";
	foreach($tb_tab as $name) {
		if( array_search( strtolower($name), $my_tab ) === FALSE )
		echo $name."\n";
	}
}

function exportGraphics($table_name) {
	$odbc_query = "SELECT * FROM " . $table_name;
	mkdir("TI/" . $table_name);
	$data = odbc_exec($this->odbc_id, $odbc_query);
	odbc_longreadlen($data, 10485760); //10MB = 10485760

	$i = 1;
// Tag: 02
//	while(odbc_fetch_row($data))
	while($row = odbc_fetch_array($data))
	{
		if($row['GRD_ID'] != "") {
			$file_name_jp2 = "TI/" . $table_name . "/" . $row['GRD_ID'] . ".jp2";
			$file = fopen ($file_name_jp2, "w");
			fputs($file, $row['GRD_GRAPHIC']);
			fclose($file);
			set_time_limit(3600);
		}
// Tag:
		unset($row);
		
		if( self::DEBUG  && ++$i > self::DEBUG_MAX ) break;		
	}
	print Tools::utf2oem("Экспорт картинок из таблицы " . $table_name . " завершен!\n");
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->odbcConnect(); //Коннект к базе Transbase
$tecdoc->mysqlConnect(); //Коннект к базе MySQL

$TB_TABLES = $tecdoc->TB_TableList(); //Список таблиц для экспорта
//$My_TABLES = $tecdoc->My_TableList(); //Список таблиц для экспорта

//Показать какие таблицы отсутствуют в MySQL (исключая графику)
// $tecdoc->Show_Diff( $TB_TABLES, $My_TABLES );

$My_TABLES = array(
/* 
"tof_accessory_lists",
"tof_acl_criteria",
"tof_ali_coordinates",
"tof_art_country_specifics", 
"tof_art_lookup",
"tof_article_criteria",
"tof_article_info",
"tof_article_list_criteria",
"tof_article_lists",
"tof_articles",
"tof_articles_new",
"tof_axl_brake_sizes",
"tof_axles",
"tof_brands",
"tof_const_pattern_lookup",
"tof_countries",
"tof_country_designations",
"tof_criteria",
"tof_cv_cabs",
"tof_cv_marks",
"tof_cv_secondary_types",
"tof_des_texts",
"tof_designations",
"tof_doc_types",
"tof_eng_country_specifics",
"tof_eng_lookup",
"tof_engines",
"tof_err_track_key_values",
"tof_filters",
"tof_generic_articles",
"tof_graphics",
"tof_key_values",
"tof_la_criteria",
"tof_la_info",
"tof_languages",
"tof_link_art",
"tof_link_art_ga",
"tof_link_cab_typ",
"tof_link_ga_cri",
"tof_link_ga_str",
"tof_link_gra_art",
"tof_link_gra_la",
"tof_link_la_axl",
"tof_link_la_axl_new",
"tof_link_la_eng",
"tof_link_la_eng_new",
"tof_link_la_mrk",
"tof_link_la_mrk_new",
"tof_link_la_typ",
"tof_link_la_typ_new",
"tof_link_sho_str",
"tof_link_sho_str_type",
"tof_link_typ_eng",
"tof_link_typ_mrk",
"tof_manufacturers",
"tof_mod_typ_lookup",
"tof_models",
*/
"tof_numberplates_nl",
"tof_parameters",
"tof_prices",
"tof_search_tree",
"tof_shortcuts",
"tof_str_family_tree",
"tof_str_lookup",
"tof_superseded_articles",
"tof_supplier_addresses",
"tof_suppliers",
"tof_text_module_texts",
"tof_text_modules",
"tof_typ_country_specifics",
"tof_typ_suspensions",
"tof_typ_voltages",
"tof_typ_wheel_bases",
"tof_type_numbers",
"tof_types",
"tof_utility_direct"
);

foreach($My_TABLES as $name) {
	$tecdoc->exportFromTransbase($name);
}

?>
