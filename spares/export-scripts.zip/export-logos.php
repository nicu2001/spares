<?php
// Экспорт Лого графики
//
class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $odbc_serv = "localhost";
var $odbc_login = "tecdoc";
var $odbc_pass = "tcd_error_0";
var $odbc_db = "TECDOC_CD_2_2011";
var $odbc_driver = "Transbase ODBC TECDOC CD 2_2011";
var $odbc_id = "";

const DEBUG = false;
const DEBUG_MAX = 3;
const BASE_IMG_DIR = "G:/tecdoc_logos";

function odbcConnect() {
	$constr = "Driver={" . $this->odbc_driver . "};Database=" . $this->odbc_db . "@" . $this->odbc_serv;
	$this->odbc_id = odbc_connect($constr, $this->odbc_login, $this->odbc_pass);
	odbc_autocommit($this->odbc_id, TRUE);
}

function exportLogos() {
    $dir = self::BASE_IMG_DIR;
    if (!is_dir($dir)) {mkdir($dir,0777,true);}
    $query = "SELECT * FROM tof_supplier_logos WHERE SLO_CTM subrange(223 cast integer) = 1";        
    $result =  odbc_exec($this->odbc_id, $query);
    odbc_longreadlen($result, 20485760);

    while($row = odbc_fetch_array($result)) {        
        $file_name = $dir."/".$row['SLO_SUP_ID'].".png";
		echo $file_name."\n";
        $file = fopen($file_name, "w");
        fputs($file, $row['SLO_LOGO']);
        fclose($file);
        set_time_limit(3600);
        unset($row);
    }
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->odbcConnect(); //Коннект к базе Transbase
$tecdoc->exportLogos();

?>
