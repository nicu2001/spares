<?php

require_once("ado.inc.php");

class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $odbc_id = "";
var $odb = "";

const DEBUG = false;
const DEBUG_MAX = 100;

function adoConnect() {
	$this->odbc_id = ado_connect("MYTECDOC");
}

function exportFromTransbase($table_name) {

	$req = "select * from tof_des_texts where tex_id in (873587,875585,879500,884090,887114)";

	$data = ado_query($this->odbc_id, $req);
	
	$fcount = ado_num_fields($data);
	for( $k=0; $k<$fcount; $k++ ) { 
		$fnames[] = ado_field_name($data, $k);
	}
    echo implode("\t",$fnames)."\n"; 

	while( ($values = ado_fetch_row($data)) !== false )
	{
	    echo Tools::ansi2oem(implode( "\t", $values ))."\n";
	}
	ado_free_result($data);
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->adoConnect(); //Коннект к базе Transbase

$tecdoc->exportFromTransbase("tof_des_texts");
?>
