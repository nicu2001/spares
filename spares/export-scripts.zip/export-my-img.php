<?php
// Экспорт таблиц графики.
// Формат jp2 (jpeg2000) в последующем не рекомендуется
// конвертировать в png (рост в 10 раз)
// или jpg (рост в 3 раза)
//
class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $odbc_serv = "localhost";
var $odbc_login = "tecdoc";
var $odbc_pass = "tcd_error_0";
var $odbc_db = "TECDOC_CD_2_2011";
var $odbc_driver = "Transbase ODBC TECDOC CD 2_2011";
var $odbc_id = "";

const DEBUG = false;
const DEBUG_MAX = 3;
const BASE_IMG_DIR = "G:/tecdoc_img";

function odbcConnect() {
	$constr = "Driver={" . $this->odbc_driver . "};Database=" . $this->odbc_db . "@" . $this->odbc_serv;
	$this->odbc_id = odbc_connect($constr, $this->odbc_login, $this->odbc_pass);
	odbc_autocommit($this->odbc_id, TRUE);
}

function exportGraphics() {
    $odbc_query = "select GRA_DOC_TYPE, GRA_GRD_ID, GRA_TAB_NR ".
				"from tof_graphics where GRA_TAB_NR is NOT NULL order by GRA_GRD_ID";
    $data =  odbc_exec($this->odbc_id, $odbc_query);
    odbc_longreadlen($data, 20485760);
	$i = 1;
    while($row =  odbc_fetch_array($data)) {
        if($row['GRA_GRD_ID'] != "" ) {
            $this->exportFile($row['GRA_GRD_ID'],$row['GRA_TAB_NR'],$row['GRA_DOC_TYPE']);
        }
		if( self::DEBUG  && ++$i > self::DEBUG_MAX ) break;		
	}
	print Tools::utf2oem("Экспорт картинок завершен!\n");
}

function exportFile($grd_id,$tab_num,$doctype) {
    $dir = self::BASE_IMG_DIR . "/". $tab_num;
	$tab_name = "TOF_GRA_DATA_".$tab_num;
    if (!is_dir($dir)) {mkdir($dir,0777,true);}
    switch ($doctype) {
        case 1: $ext = 'bmp'; break;
        case 2: $ext = 'pdf'; break;
        case 3: $ext = 'jpg'; break;
        case 4: $ext = 'jp2'; break;
        case 5: $ext = 'png'; break;
        case 0: $ext = 'null'; break;
    }    
    $query = "SELECT * FROM $tab_name WHERE GRD_ID=$grd_id";        
    $result =  odbc_exec($this->odbc_id, $query);
    odbc_longreadlen($result, 20485760);

    while($row = odbc_fetch_array($result)) {        
        $file_name = $dir."/".$grd_id.".".$ext;
		echo $file_name."\n";
        $file = fopen($file_name, "w");
        fputs($file, $row['GRD_GRAPHIC']);
        fclose($file);
        set_time_limit(3600);
        unset($row);
    }
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->odbcConnect(); //Коннект к базе Transbase
$tecdoc->exportGraphics();

?>
