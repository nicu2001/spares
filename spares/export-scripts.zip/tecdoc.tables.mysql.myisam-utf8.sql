﻿-- MySQL dump 10.11
--
-- Host: localhost    Database: tecdoc_2010_2q_full_sample
-- ------------------------------------------------------
-- Server version	5.0.32-Debian_7etch11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ACCESSORY_LISTS`
--

DROP TABLE IF EXISTS `TOF_ACCESSORY_LISTS`;
CREATE TABLE `TOF_ACCESSORY_LISTS` (
  `ACL_ART_ID` int(11) NOT NULL,
  `ACL_NR` smallint(6) NOT NULL,
  `ACL_SORT` smallint(6) NOT NULL,
  `ACL_LINK_TYPE` smallint(6) default NULL,
  `ACL_MFA_ID` smallint(6) default NULL,
  `ACL_MOD_ID` int(11) default NULL,
  `ACL_TYP_ID` int(11) default NULL,
  `ACL_ENG_ID` int(11) default NULL,
  `ACL_ACCESSORY_ART_ID` int(11) default NULL,
  `ACL_QUANTITY` smallint(6) default NULL,
  `ACL_GA_ID` int(11) default NULL,
  `ACL_CTM` binary(252) default NULL,
  `ACL_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ACL_CRITERIA`
--

DROP TABLE IF EXISTS `TOF_ACL_CRITERIA`;
CREATE TABLE `TOF_ACL_CRITERIA` (
  `ACC_ART_ID` int(11) NOT NULL,
  `ACC_NR` smallint(6) NOT NULL,
  `ACC_SORT` smallint(6) NOT NULL,
  `ACC_SEQ_NR` smallint(6) NOT NULL,
  `ACC_CRI_ID` smallint(6) default NULL,
  `ACC_VALUE` varchar(60) default NULL,
  `ACC_KV_DES_ID` int(11) default NULL,
  `ACC_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ALI_COORDINATES`
--

DROP TABLE IF EXISTS `TOF_ALI_COORDINATES`;
CREATE TABLE `TOF_ALI_COORDINATES` (
  `ACO_GRA_ID` varchar(11) NOT NULL,
  `ACO_GRA_LNG_ID` smallint(6) NOT NULL,
  `ACO_ALI_ART_ID` int(11) NOT NULL,
  `ACO_ALI_SORT` smallint(6) NOT NULL,
  `ACO_SORT` smallint(6) NOT NULL,
  `ACO_TYPE` smallint(6) default NULL,
  `ACO_X1` smallint(6) default NULL,
  `ACO_Y1` smallint(6) default NULL,
  `ACO_X2` smallint(6) default NULL,
  `ACO_Y2` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLES`
--

DROP TABLE IF EXISTS `TOF_ARTICLES`;
CREATE TABLE `TOF_ARTICLES` (
  `ART_ID` int(11) NOT NULL,
  `ART_ARTICLE_NR` varchar(66) NOT NULL,
  `ART_SUP_ID` smallint(6) default NULL,
  `ART_DES_ID` int(11) default NULL,
  `ART_COMPLETE_DES_ID` int(11) default NULL,
  `ART_CTM` binary(252) default NULL,
  `ART_PACK_SELFSERVICE` smallint(6) default NULL,
  `ART_MATERIAL_MARK` smallint(6) default NULL,
  `ART_REPLACEMENT` smallint(6) default NULL,
  `ART_ACCESSORY` smallint(6) default NULL,
  `ART_BATCH_SIZE1` int(11) default NULL,
  `ART_BATCH_SIZE2` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLES_NEW`
--

DROP TABLE IF EXISTS `TOF_ARTICLES_NEW`;
CREATE TABLE `TOF_ARTICLES_NEW` (
  `ARTN_SUP_ID` smallint(6) NOT NULL default '0',
  `ARTN_ART_ID` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLE_CRITERIA`
--

DROP TABLE IF EXISTS `TOF_ARTICLE_CRITERIA`;
CREATE TABLE `TOF_ARTICLE_CRITERIA` (
  `ACR_ART_ID` int(11) NOT NULL,
  `ACR_GA_ID` int(11) NOT NULL,
  `ACR_SORT` smallint(6) NOT NULL,
  `ACR_CRI_ID` smallint(6) NOT NULL,
  `ACR_VALUE` varchar(60) default NULL,
  `ACR_KV_DES_ID` int(11) default NULL,
  `ACR_CTM` binary(252) default NULL,
  `ACR_DISPLAY` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLE_INFO`
--

DROP TABLE IF EXISTS `TOF_ARTICLE_INFO`;
CREATE TABLE `TOF_ARTICLE_INFO` (
  `AIN_ART_ID` int(11) NOT NULL,
  `AIN_GA_ID` int(11) NOT NULL,
  `AIN_SORT` smallint(6) NOT NULL,
  `AIN_CTM` binary(252) default NULL,
  `AIN_KV_TYPE` varchar(9) NOT NULL default '',
  `AIN_DISPLAY` smallint(6) NOT NULL default '0',
  `AIN_TMO_ID` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLE_LISTS`
--

DROP TABLE IF EXISTS `TOF_ARTICLE_LISTS`;
CREATE TABLE `TOF_ARTICLE_LISTS` (
  `ALI_ART_ID` int(11) NOT NULL,
  `ALI_SORT` smallint(6) NOT NULL,
  `ALI_ART_ID_COMPONENT` int(11) default NULL,
  `ALI_QUANTITY` smallint(6) default NULL,
  `ALI_CTM` binary(252) default NULL,
  `ALI_GA_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ARTICLE_LIST_CRITERIA`
--

DROP TABLE IF EXISTS `TOF_ARTICLE_LIST_CRITERIA`;
CREATE TABLE `TOF_ARTICLE_LIST_CRITERIA` (
  `ALC_ALI_ART_ID` int(11) NOT NULL,
  `ALC_ALI_SORT` smallint(6) NOT NULL,
  `ALC_CTM` binary(252) default NULL,
  `ALC_SORT` smallint(6) NOT NULL default '0',
  `ALC_CRI_ID` smallint(6) NOT NULL default '0',
  `ALC_VALUE` varchar(60) NOT NULL default '',
  `ALC_KV_DES_ID` int(11) NOT NULL default '0',
  `ALC_TYP_ID` int(11) NOT NULL default '0',
  `ALC_ENG_ID` int(11) NOT NULL default '0',
  `ALC_AXL_ID` int(11) NOT NULL default '0',
  `ALC_MRK_ID` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ART_COUNTRY_SPECIFICS`
--

DROP TABLE IF EXISTS `TOF_ART_COUNTRY_SPECIFICS`;
CREATE TABLE `TOF_ART_COUNTRY_SPECIFICS` (
  `ACS_ART_ID` int(11) NOT NULL,
  `ACS_CTM` binary(252) NOT NULL,
  `ACS_PACK_UNIT` int(11) default NULL,
  `ACS_QUANTITY_PER_UNIT` int(11) default NULL,
  `ACS_KV_STATUS_DES_ID` int(11) default NULL,
  `ACS_KV_STATUS` varchar(9) default NULL,
  `ACS_STATUS_DATE` datetime default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ART_LOOKUP`
--

DROP TABLE IF EXISTS `TOF_ART_LOOKUP`;
CREATE TABLE `TOF_ART_LOOKUP` (
  `ARL_ART_ID` int(11) NOT NULL default '0',
  `ARL_SEARCH_NUMBER` varchar(105) NOT NULL default '',
  `ARL_KIND` binary(1) NOT NULL default '\0',
  `ARL_CTM` binary(252) default NULL,
  `ARL_BRA_ID` smallint(6) NOT NULL default '0',
  `ARL_DISPLAY_NR` varchar(105) NOT NULL default '',
  `ARL_DISPLAY` smallint(6) NOT NULL default '0',
  `ARL_BLOCK` smallint(6) NOT NULL default '0',
  `ARL_SORT` smallint(6) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `AXLES`
--

DROP TABLE IF EXISTS `TOF_AXLES`;
CREATE TABLE `TOF_AXLES` (
  `AXL_ID` int(11) NOT NULL,
  `AXL_DESCRIPTION` varchar(90) default NULL,
  `AXL_SEARCH_TEXT` varchar(90) default NULL,
  `AXL_MMA_CDS_ID` int(11) default NULL,
  `AXL_MOD_ID` int(11) default NULL,
  `AXL_SORT` int(11) default NULL,
  `AXL_PCON_START` int(11) default NULL,
  `AXL_PCON_END` int(11) default NULL,
  `AXL_KV_TYPE_DES_ID` int(11) default NULL,
  `AXL_KV_STYLE_DES_ID` int(11) default NULL,
  `AXL_KV_BRAKE_TYPE_DES_ID` int(11) default NULL,
  `AXL_KV_BODY_DES_ID` int(11) default NULL,
  `AXL_LOAD_FROM` int(11) default NULL,
  `AXL_LOAD_UPTO` int(11) default NULL,
  `AXL_KV_WHEEL_MOUNT_DES_ID` int(11) default NULL,
  `AXL_TRACK_GAUGE` int(11) default NULL,
  `AXL_HUB_SYSTEM` varchar(60) default NULL,
  `AXL_DISTANCE_FROM` int(11) default NULL,
  `AXL_DISTANCE_UPTO` int(11) default NULL,
  `AXL_SEARCH_BRAKE_SIZES` varchar(256) default NULL,
  `AXL_LA_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `AXL_BRAKE_SIZES`
--

DROP TABLE IF EXISTS `TOF_AXL_BRAKE_SIZES`;
CREATE TABLE `TOF_AXL_BRAKE_SIZES` (
  `ABS_AXL_ID` int(11) NOT NULL,
  `ABS_SORT` smallint(6) NOT NULL,
  `ABS_KV_BRAKE_SIZE_DES_ID` int(11) default NULL,
  `ABS_DESCRIPTION` varchar(60) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `BRANDS`
--

DROP TABLE IF EXISTS `TOF_BRANDS`;
CREATE TABLE `TOF_BRANDS` (
  `BRA_ID` smallint(6) NOT NULL,
  `BRA_MFC_CODE` varchar(60) default NULL,
  `BRA_BRAND` varchar(60) default NULL,
  `BRA_MF_NR` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `CONST_PATTERN_LOOKUP`
--

DROP TABLE IF EXISTS `TOF_CONST_PATTERN_LOOKUP`;
CREATE TABLE `TOF_CONST_PATTERN_LOOKUP` (
  `CPL_ID` int(11) NOT NULL,
  `CPL_CTM` binary(252) default NULL,
  `CPL_SORT` smallint(6) NOT NULL default '0',
  `CPL_ORIGINAL_TEXT` varchar(60) NOT NULL,
  `CPL_SEARCH_TEXT` varchar(60) NOT NULL default '',
  `CPL_KIND` smallint(6) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `COUNTRIES`
--

DROP TABLE IF EXISTS `TOF_COUNTRIES`;
CREATE TABLE `TOF_COUNTRIES` (
  `COU_ID` smallint(6) NOT NULL,
  `COU_CC` varchar(9) default NULL,
  `COU_DES_ID` int(11) default NULL,
  `COU_CTM` binary(252) default NULL,
  `COU_CURRENCY_CODE` varchar(9) default NULL,
  `COU_ISO2` varchar(6) default NULL,
  `COU_IS_GROUP` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `COUNTRY_DESIGNATIONS`
--

DROP TABLE IF EXISTS `TOF_COUNTRY_DESIGNATIONS`;
CREATE TABLE `TOF_COUNTRY_DESIGNATIONS` (
  `CDS_ID` int(11) NOT NULL,
  `CDS_CTM` binary(252) NOT NULL,
  `CDS_LNG_ID` smallint(6) NOT NULL,
  `CDS_TEX_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `CRITERIA`
--

DROP TABLE IF EXISTS `TOF_CRITERIA`;
CREATE TABLE `TOF_CRITERIA` (
  `CRI_ID` smallint(6) NOT NULL,
  `CRI_DES_ID` int(11) NOT NULL,
  `CRI_SHORT_DES_ID` int(11) default NULL,
  `CRI_UNIT_DES_ID` int(11) default NULL,
  `CRI_TYPE` binary(1) NOT NULL,
  `CRI_KT_ID` smallint(6) default NULL,
  `CRI_IS_INTERVAL` smallint(6) default NULL,
  `CRI_SUCCESSOR` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `CV_CABS`
--

DROP TABLE IF EXISTS `TOF_CV_CABS`;
CREATE TABLE `TOF_CV_CABS` (
  `CAB_ID` int(11) NOT NULL,
  `CAB_MOD_ID` int(11) default NULL,
  `CAB_CDS_ID` int(11) NOT NULL,
  `CAB_MMC_CDS_ID` int(11) default NULL,
  `CAB_KV_SIZE_DES_ID` int(11) default NULL,
  `CAB_PCON_START` int(11) default NULL,
  `CAB_PCON_END` int(11) default NULL,
  `CAB_CTM` binary(252) default NULL,
  `X_CAB_DESIGN` varchar(90) default NULL,
  `X_CAB_LENGTH` int(11) default NULL,
  `X_CAB_HEIGHT` int(11) default NULL,
  `X_CAB_WIDTH` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `CV_MARKS`
--

DROP TABLE IF EXISTS `TOF_CV_MARKS`;
CREATE TABLE `TOF_CV_MARKS` (
  `MRK_ID` int(11) NOT NULL,
  `MRK_DESIGNATION` varchar(60) default NULL,
  `MRK_SEARCH_TEXT` varchar(60) default NULL,
  `MRK_MFA_ID` smallint(6) default NULL,
  `MRK_CTM` binary(252) default NULL,
  `MRK_LA_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `CV_SECONDARY_TYPES`
--

DROP TABLE IF EXISTS `TOF_CV_SECONDARY_TYPES`;
CREATE TABLE `TOF_CV_SECONDARY_TYPES` (
  `CST_TYP_ID` int(11) NOT NULL,
  `CST_SUBNR` smallint(6) NOT NULL,
  `CST_SORT` smallint(6) NOT NULL,
  `CST_CDS_ID` int(11) default NULL,
  `CST_PCON_START` int(11) default NULL,
  `CST_PCON_END` int(11) default NULL,
  `CST_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `DESIGNATIONS`
--

DROP TABLE IF EXISTS `TOF_DESIGNATIONS`;
CREATE TABLE `TOF_DESIGNATIONS` (
  `DES_ID` int(11) NOT NULL,
  `DES_LNG_ID` smallint(6) NOT NULL,
  `DES_TEX_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `DES_TEXTS`
--

DROP TABLE IF EXISTS `TOF_DES_TEXTS`;
CREATE TABLE `TOF_DES_TEXTS` (
  `TEX_ID` int(11) NOT NULL,
  `TEX_TEXT` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `DOC_TYPES`
--

DROP TABLE IF EXISTS `TOF_DOC_TYPES`;
CREATE TABLE `TOF_DOC_TYPES` (
  `DOC_TYPE` smallint(4) NOT NULL,
  `DOC_EXTENSION` varchar(9) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ENGINES`
--

DROP TABLE IF EXISTS `TOF_ENGINES`;
CREATE TABLE `TOF_ENGINES` (
  `ENG_ID` int(11) NOT NULL,
  `ENG_MFA_ID` smallint(6) default NULL,
  `ENG_CODE` varchar(180) NOT NULL,
  `ENG_PCON_START` int(11) default NULL,
  `ENG_PCON_END` int(11) default NULL,
  `ENG_KW_FROM` int(11) default NULL,
  `ENG_KW_UPTO` int(11) default NULL,
  `ENG_HP_FROM` int(11) default NULL,
  `ENG_HP_UPTO` int(11) default NULL,
  `ENG_VALVES` smallint(6) default NULL,
  `ENG_CYLINDERS` smallint(6) default NULL,
  `ENG_CCM_FROM` int(11) default NULL,
  `ENG_CCM_UPTO` int(11) default NULL,
  `ENG_KV_DESIGN_DES_ID` int(11) default NULL,
  `ENG_KV_FUEL_TYPE_DES_ID` int(11) default NULL,
  `ENG_KV_FUEL_SUPPLY_DES_ID` int(11) default NULL,
  `ENG_CTM` binary(252) default NULL,
  `ENG_LA_CTM` binary(252) default NULL,
  `ENG_DESCRIPTION` varchar(90) default NULL,
  `ENG_KV_ENGINE_DES_ID` int(11) default NULL,
  `ENG_KW_RPM_FROM` int(11) default NULL,
  `ENG_KW_RPM_UPTO` int(11) default NULL,
  `ENG_TORQUE_FROM` int(11) default NULL,
  `ENG_TORQUE_UPTO` int(11) default NULL,
  `ENG_TORQUE_RPM_FROM` int(11) default NULL,
  `ENG_TORQUE_RPM_UPTO` int(11) default NULL,
  `ENG_COMPRESSION_FROM` double default NULL,
  `ENG_COMPRESSION_UPTO` double default NULL,
  `ENG_DRILLING` double default NULL,
  `ENG_EXTENSION` double default NULL,
  `ENG_CRANKSHAFT` smallint(6) default NULL,
  `ENG_KV_CHARGE_DES_ID` int(11) default NULL,
  `ENG_KV_GAS_NORM_DES_ID` int(11) default NULL,
  `ENG_KV_CYLINDERS_DES_ID` int(11) default NULL,
  `ENG_KV_CONTROL_DES_ID` int(11) default NULL,
  `ENG_KV_VALVE_CONTROL_DES_ID` int(11) default NULL,
  `ENG_KV_COOLING_DES_ID` int(11) default NULL,
  `ENG_CCM_TAX_FROM` int(11) default NULL,
  `ENG_CCM_TAX_UPTO` int(11) default NULL,
  `ENG_LITRES_TAX_FROM` double default NULL,
  `ENG_LITRES_TAX_UPTO` double default NULL,
  `ENG_LITRES_FROM` double default NULL,
  `ENG_LITRES_UPTO` double default NULL,
  `ENG_KV_USE_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ENG_COUNTRY_SPECIFICS`
--

DROP TABLE IF EXISTS `TOF_ENG_COUNTRY_SPECIFICS`;
CREATE TABLE `TOF_ENG_COUNTRY_SPECIFICS` (
  `ENC_ENG_ID` int(11) NOT NULL,
  `ENC_COU_ID` smallint(6) NOT NULL,
  `ENC_PCON_START` int(11) default NULL,
  `ENC_PCON_END` int(11) default NULL,
  `ENC_KW_FROM` int(11) default NULL,
  `ENC_KW_UPTO` int(11) default NULL,
  `ENC_HP_FROM` int(11) default NULL,
  `ENC_HP_UPTO` int(11) default NULL,
  `ENC_VALVES` smallint(6) default NULL,
  `ENC_CYLINDERS` smallint(6) default NULL,
  `ENC_CCM_FROM` int(11) default NULL,
  `ENC_CCM_UPTO` int(11) default NULL,
  `ENC_KV_DESIGN_DES_ID` int(11) default NULL,
  `ENC_KV_FUEL_TYPE_DES_ID` int(11) default NULL,
  `ENC_KV_FUEL_SUPPLY_DES_ID` int(11) default NULL,
  `ENC_DESCRIPTION` varchar(90) default NULL,
  `ENC_KV_ENGINE_DES_ID` int(11) default NULL,
  `ENC_KW_RPM_FROM` int(11) default NULL,
  `ENC_KW_RPM_UPTO` int(11) default NULL,
  `ENC_TORQUE_FROM` int(11) default NULL,
  `ENC_TORQUE_UPTO` int(11) default NULL,
  `ENC_TORQUE_RPM_FROM` int(11) default NULL,
  `ENC_TORQUE_RPM_UPTO` int(11) default NULL,
  `ENC_COMPRESSION_FROM` double default NULL,
  `ENC_COMPRESSION_UPTO` double default NULL,
  `ENC_DRILLING` double default NULL,
  `ENC_EXTENSION` double default NULL,
  `ENC_CRANKSHAFT` smallint(6) default NULL,
  `ENC_KV_CHARGE_DES_ID` int(11) default NULL,
  `ENC_KV_GAS_NORM_DES_ID` int(11) default NULL,
  `ENC_KV_CYLINDERS_DES_ID` int(11) default NULL,
  `ENC_KV_CONTROL_DES_ID` int(11) default NULL,
  `ENC_KV_VALVE_CONTROL_DES_ID` int(11) default NULL,
  `ENC_KV_COOLING_DES_ID` int(11) default NULL,
  `ENC_CCM_TAX_FROM` int(11) default NULL,
  `ENC_CCM_TAX_UPTO` int(11) default NULL,
  `ENC_LITRES_TAX_FROM` double default NULL,
  `ENC_LITRES_TAX_UPTO` double default NULL,
  `ENC_LITRES_FROM` double default NULL,
  `ENC_LITRES_UPTO` double default NULL,
  `ENC_KV_USE_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ENG_LOOKUP`
--

DROP TABLE IF EXISTS `TOF_ENG_LOOKUP`;
CREATE TABLE `TOF_ENG_LOOKUP` (
  `ENL_ENG_ID` int(11) default NULL,
  `ENL_SEARCH_TEXT` varchar(180) default NULL,
  `ENL_CTM` binary(252) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `ERR_TRACK_KEY_VALUES`
--

DROP TABLE IF EXISTS `TOF_ERR_TRACK_KEY_VALUES`;
CREATE TABLE `TOF_ERR_TRACK_KEY_VALUES` (
  `ETK_TAB_NR` smallint(6) NOT NULL,
  `ETK_KEY` varchar(9) NOT NULL,
  `ETK_LNG_ID` smallint(6) NOT NULL,
  `ETK_SORTNR` smallint(6) default NULL,
  `ETK_DESCRIPTION` varchar(180) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `FILTERS`
--

DROP TABLE IF EXISTS `TOF_FILTERS`;
CREATE TABLE `TOF_FILTERS` (
  `FIL_USS_ID` int(11) NOT NULL,
  `FIL_KIND` smallint(6) NOT NULL,
  `FIL_VALUE` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `GENERIC_ARTICLES`
--

DROP TABLE IF EXISTS `TOF_GENERIC_ARTICLES`;
CREATE TABLE `TOF_GENERIC_ARTICLES` (
  `GA_ID` int(11) NOT NULL,
  `GA_NR` smallint(6) default NULL,
  `GA_DES_ID` int(11) NOT NULL,
  `GA_DES_ID_STANDARD` int(11) NOT NULL,
  `GA_DES_ID_ASSEMBLY` int(11) default NULL,
  `GA_DES_ID_INTENDED` int(11) default NULL,
  `GA_UNIVERSAL` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `GRAPHICS`
--

DROP TABLE IF EXISTS `TOF_GRAPHICS`;
CREATE TABLE `TOF_GRAPHICS` (
  `GRA_SUP_ID` smallint(6) default NULL,
  `GRA_ID` varchar(11) NOT NULL,
  `GRA_DOC_TYPE` tinyint(4) default NULL,
  `GRA_LNG_ID` smallint(6) NOT NULL,
  `GRA_GRD_ID` int(11) default NULL,
  `GRA_TYPE` smallint(6) default NULL,
  `GRA_NORM` varchar(9) default NULL,
  `GRA_SUPPLIER_NR` smallint(6) default NULL,
  `GRA_TAB_NR` smallint(6) default NULL,
  `GRA_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `KEY_VALUES`
--

DROP TABLE IF EXISTS `TOF_KEY_VALUES`;
CREATE TABLE `TOF_KEY_VALUES` (
  `KV_KT_ID` smallint(6) NOT NULL,
  `KV_KV` varchar(9) NOT NULL,
  `KV_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LANGUAGES`
--

DROP TABLE IF EXISTS `TOF_LANGUAGES`;
CREATE TABLE `TOF_LANGUAGES` (
  `LNG_ID` smallint(6) NOT NULL,
  `LNG_DES_ID` int(11) default NULL,
  `LNG_ISO2` varchar(6) default NULL,
  `LNG_CODEPAGE` varchar(30) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LA_CRITERIA`
--

DROP TABLE IF EXISTS `TOF_LA_CRITERIA`;
CREATE TABLE `TOF_LA_CRITERIA` (
  `LAC_LA_ID` int(11) NOT NULL,
  `LAC_SORT` int(11) NOT NULL,
  `LAC_CRI_ID` smallint(6) NOT NULL,
  `LAC_VALUE` varchar(60) default NULL,
  `LAC_KV_DES_ID` int(11) default NULL,
  `LAC_CTM` binary(252) NOT NULL,
  `LAC_DISPLAY` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LA_INFO`
--

DROP TABLE IF EXISTS `TOF_LA_INFO`;
CREATE TABLE `TOF_LA_INFO` (
  `LIN_LA_ID` int(11) NOT NULL,
  `LIN_SORT` smallint(6) NOT NULL,
  `LIN_CTM` binary(252) NOT NULL,
  `LIN_KV_TYPE` varchar(9) NOT NULL,
  `LIN_DISPLAY` smallint(6) NOT NULL,
  `LIN_TMO_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_ART`
--

DROP TABLE IF EXISTS `TOF_LINK_ART`;
CREATE TABLE `TOF_LINK_ART` (
  `LA_ID` int(11) NOT NULL,
  `LA_ART_ID` int(11) NOT NULL,
  `LA_GA_ID` int(11) NOT NULL,
  `LA_CTM` binary(252) NOT NULL,
  `LA_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_ART_GA`
--

DROP TABLE IF EXISTS `TOF_LINK_ART_GA`;
CREATE TABLE `TOF_LINK_ART_GA` (
  `LAG_ART_ID` int(11) NOT NULL,
  `LAG_GA_ID` int(11) NOT NULL,
  `LAG_SUP_ID` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_CAB_TYP`
--

DROP TABLE IF EXISTS `TOF_LINK_CAB_TYP`;
CREATE TABLE `TOF_LINK_CAB_TYP` (
  `LCT_TYP_ID` int(11) NOT NULL,
  `LCT_NR` smallint(6) NOT NULL,
  `LCT_CAB_ID` int(11) NOT NULL,
  `LCT_PCON_START` int(11) NOT NULL default '0',
  `LCT_PCON_END` int(11) NOT NULL default '0',
  `LCT_CTM` binary(252) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_GA_CRI`
--

DROP TABLE IF EXISTS `TOF_LINK_GA_CRI`;
CREATE TABLE `TOF_LINK_GA_CRI` (
  `LGC_GA_NR` smallint(6) NOT NULL,
  `LGC_CRI_ID` smallint(6) NOT NULL,
  `LGC_CTM` binary(252) NOT NULL,
  `LGC_SORT` smallint(6) NOT NULL,
  `LGC_SUGGESTION` smallint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_GA_STR`
--

DROP TABLE IF EXISTS `TOF_LINK_GA_STR`;
CREATE TABLE `TOF_LINK_GA_STR` (
  `LGS_STR_ID` int(11) NOT NULL,
  `LGS_GA_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_GRA_ART`
--

DROP TABLE IF EXISTS `TOF_LINK_GRA_ART`;
CREATE TABLE `TOF_LINK_GRA_ART` (
  `LGA_ART_ID` int(11) NOT NULL,
  `LGA_SORT` smallint(6) NOT NULL,
  `LGA_CTM` binary(252) NOT NULL,
  `LGA_GRA_ID` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_GRA_LA`
--

DROP TABLE IF EXISTS `TOF_LINK_GRA_LA`;
CREATE TABLE `TOF_LINK_GRA_LA` (
  `LGL_LA_ID` int(11) NOT NULL,
  `LGL_TYP_ID` int(11) NOT NULL default '0',
  `LGL_ENG_ID` int(11) NOT NULL default '0',
  `LGL_AXL_ID` int(11) NOT NULL default '0',
  `LGL_MRK_ID` int(11) NOT NULL default '0',
  `LGL_SORT` smallint(6) NOT NULL,
  `LGL_CTM` binary(252) NOT NULL,
  `LGL_GRA_ID` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_AXL`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_AXL`;
CREATE TABLE `TOF_LINK_LA_AXL` (
  `LAA_LA_ID` int(11) NOT NULL,
  `LAA_AXL_ID` int(11) NOT NULL,
  `LAA_GA_ID` int(11) NOT NULL,
  `LAA_CTM` binary(252) NOT NULL,
  `LAA_SUP_ID` smallint(6) default NULL,
  `LAA_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_AXL_NEW`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_AXL_NEW`;
CREATE TABLE `TOF_LINK_LA_AXL_NEW` (
  `LAAN_LA_ID` int(11) NOT NULL,
  `LAAN_AXL_ID` int(11) NOT NULL,
  `LAAN_GA_ID` int(11) NOT NULL,
  `LAAN_CTM` binary(252) NOT NULL,
  `LAAN_SUP_ID` smallint(6) NOT NULL default '0',
  `LAAN_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_ENG`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_ENG`;
CREATE TABLE `TOF_LINK_LA_ENG` (
  `LAE_LA_ID` int(11) NOT NULL,
  `LAE_ENG_ID` int(11) NOT NULL,
  `LAE_GA_ID` int(11) NOT NULL,
  `LAE_CTM` binary(252) default NULL,
  `LAE_SUP_ID` smallint(6) default NULL,
  `LAE_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_ENG_NEW`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_ENG_NEW`;
CREATE TABLE `TOF_LINK_LA_ENG_NEW` (
  `LAEN_SUP_ID` smallint(6) NOT NULL default '0',
  `LAEN_GA_ID` int(11) NOT NULL default '0',
  `LAEN_LA_ID` int(11) NOT NULL default '0',
  `LAEN_ENG_ID` int(11) NOT NULL default '0',
  `LAEN_CTM` binary(252) default NULL,
  `LAEN_SORT` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_MRK`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_MRK`;
CREATE TABLE `TOF_LINK_LA_MRK` (
  `LAM_LA_ID` int(11) NOT NULL,
  `LAM_MRK_ID` int(11) NOT NULL,
  `LAM_GA_ID` int(11) NOT NULL,
  `LAM_CTM` binary(252) default NULL,
  `LAM_SUP_ID` smallint(6) default NULL,
  `LAM_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_MRK_NEW`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_MRK_NEW`;
CREATE TABLE `TOF_LINK_LA_MRK_NEW` (
  `LAMN_LA_ID` int(11) NOT NULL default '0',
  `LAMN_MRK_ID` int(11) NOT NULL default '0',
  `LAMN_GA_ID` int(11) NOT NULL default '0',
  `LAMN_CTM` binary(252) default NULL,
  `LAMN_SUP_ID` smallint(6) NOT NULL default '0',
  `LAMN_SORT` int(11) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_TYP`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_TYP`;
CREATE TABLE `TOF_LINK_LA_TYP` (
  `LAT_TYP_ID` int(11) NOT NULL,
  `LAT_LA_ID` int(11) NOT NULL,
  `LAT_GA_ID` int(11) NOT NULL,
  `LAT_CTM` binary(252) NOT NULL,
  `LAT_SUP_ID` smallint(6) default NULL,
  `LAT_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_LA_TYP_NEW`
--

DROP TABLE IF EXISTS `TOF_LINK_LA_TYP_NEW`;
CREATE TABLE `TOF_LINK_LA_TYP_NEW` (
  `LATN_SUP_ID` smallint(6) NOT NULL,
  `LATN_GA_ID` int(11) NOT NULL,
  `LATN_TYP_ID` int(11) NOT NULL,
  `LATN_LA_ID` int(11) NOT NULL,
  `LATN_CTM` binary(252) default NULL,
  `LATN_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_SHO_STR`
--

DROP TABLE IF EXISTS `TOF_LINK_SHO_STR`;
CREATE TABLE `TOF_LINK_SHO_STR` (
  `LSS_SHO_ID` smallint(6) NOT NULL,
  `LSS_STR_ID` int(11) NOT NULL,
  `LSS_EXPAND` smallint(6) default NULL,
  `LSS_LEVEL` smallint(6) NOT NULL,
  `LSS_SORT` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_SHO_STR_TYPE`
--

DROP TABLE IF EXISTS `TOF_LINK_SHO_STR_TYPE`;
CREATE TABLE `TOF_LINK_SHO_STR_TYPE` (
  `LST_STR_TYPE` smallint(6) NOT NULL,
  `LST_SHO_ID` smallint(6) NOT NULL,
  `LST_SORT` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_TYP_ENG`
--

DROP TABLE IF EXISTS `TOF_LINK_TYP_ENG`;
CREATE TABLE `TOF_LINK_TYP_ENG` (
  `LTE_TYP_ID` int(11) NOT NULL,
  `LTE_NR` smallint(6) NOT NULL,
  `LTE_ENG_ID` int(11) NOT NULL,
  `LTE_PCON_START` int(11) default NULL,
  `LTE_PCON_END` int(11) default NULL,
  `LTE_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `LINK_TYP_MRK`
--

DROP TABLE IF EXISTS `TOF_LINK_TYP_MRK`;
CREATE TABLE `TOF_LINK_TYP_MRK` (
  `LMK_TYP_ID` int(11) NOT NULL,
  `LMK_MRK_ID` int(11) NOT NULL,
  `LMK_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `MANUFACTURERS`
--

DROP TABLE IF EXISTS `TOF_MANUFACTURERS`;
CREATE TABLE `TOF_MANUFACTURERS` (
  `MFA_ID` smallint(6) NOT NULL,
  `MFA_PC_MFC` smallint(6) default NULL,
  `MFA_CV_MFC` smallint(6) default NULL,
  `MFA_AXL_MFC` smallint(6) default NULL,
  `MFA_ENG_MFC` smallint(6) default NULL,
  `MFA_ENG_TYP` smallint(6) default NULL,
  `MFA_MFC_CODE` varchar(30) default NULL,
  `MFA_BRAND` varchar(60) default NULL,
  `MFA_MF_NR` int(11) default NULL,
  `MFA_PC_CTM` binary(252) default NULL,
  `MFA_CV_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `MODELS`
--

DROP TABLE IF EXISTS `TOF_MODELS`;
CREATE TABLE `TOF_MODELS` (
  `MOD_ID` int(11) NOT NULL,
  `MOD_MFA_ID` smallint(6) default NULL,
  `MOD_CDS_ID` int(11) default NULL,
  `MOD_PCON_START` int(11) default NULL,
  `MOD_PCON_END` int(11) default NULL,
  `MOD_PC` smallint(6) default NULL,
  `MOD_CV` smallint(6) default NULL,
  `MOD_AXL` smallint(6) default NULL,
  `MOD_PC_CTM` binary(252) default NULL,
  `MOD_CV_CTM` binary(252) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `MOD_TYP_LOOKUP`
--

DROP TABLE IF EXISTS `TOF_MOD_TYP_LOOKUP`;
CREATE TABLE `TOF_MOD_TYP_LOOKUP` (
  `MTL_TYP_ID` int(11) NOT NULL,
  `MTL_CTM` binary(252) NOT NULL,
  `MTL_LNG_ID` smallint(6) NOT NULL,
  `MTL_SEARCH_TEXT` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `NUMBERPLATES_NL`
--

DROP TABLE IF EXISTS `TOF_NUMBERPLATES_NL`;
CREATE TABLE `TOF_NUMBERPLATES_NL` (
  `NNL_NUMBERPLATE` varchar(8) NOT NULL,
  `NNL_TYP_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `PARAMETERS`
--

DROP TABLE IF EXISTS `TOF_PARAMETERS`;
CREATE TABLE `TOF_PARAMETERS` (
  `PAR_NAME` varchar(60) NOT NULL,
  `PAR_VALUE` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `PRICES`
--

DROP TABLE IF EXISTS `TOF_PRICES`;
CREATE TABLE `TOF_PRICES` (
  `PRI_ART_ID` int(11) NOT NULL,
  `PRI_KV_PRICE_TYPE` varchar(9) NOT NULL,
  `PRI_CTM` binary(252) NOT NULL,
  `PRI_PRICE` varchar(30) default NULL,
  `PRI_KV_PRICE_UNIT_DES_ID` int(11) NOT NULL,
  `PRI_KV_QUANTITY_UNIT_DES_ID` int(11) NOT NULL,
  `PRI_VAL_START` datetime default NULL,
  `PRI_VAL_END` datetime default NULL,
  `PRI_CURRENCY_CODE` varchar(9) NOT NULL,
  `PRI_REBATE` varchar(15) default NULL,
  `PRI_DISCOUNT_FLAG` smallint(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SEARCH_TREE`
--

DROP TABLE IF EXISTS `TOF_SEARCH_TREE`;
CREATE TABLE `TOF_SEARCH_TREE` (
  `STR_ID` int(11) NOT NULL,
  `STR_ID_PARENT` int(11) default NULL,
  `STR_TYPE` smallint(6) default NULL,
  `STR_LEVEL` smallint(6) default NULL,
  `STR_DES_ID` int(11) default NULL,
  `STR_SORT` smallint(6) default NULL,
  `STR_NODE_NR` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SHORTCUTS`
--

DROP TABLE IF EXISTS `TOF_SHORTCUTS`;
CREATE TABLE `TOF_SHORTCUTS` (
  `SHO_ID` smallint(6) NOT NULL,
  `SHO_DES_ID` int(11) NOT NULL,
  `SHO_PICTURE` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `STR_FAMILY_TREE`
--

DROP TABLE IF EXISTS `TOF_STR_FAMILY_TREE`;
CREATE TABLE `TOF_STR_FAMILY_TREE` (
  `SFT_ANCESTOR_STR_ID` int(11) NOT NULL,
  `SFT_DESCENDANT_STR_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `STR_LOOKUP`
--

DROP TABLE IF EXISTS `TOF_STR_LOOKUP`;
CREATE TABLE `TOF_STR_LOOKUP` (
  `STL_LNG_ID` smallint(6) NOT NULL,
  `STL_SEARCH_TEXT` varchar(180) NOT NULL,
  `STL_STR_ID` int(11) NOT NULL,
  `STL_GA_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SUPERSEDED_ARTICLES`
--

DROP TABLE IF EXISTS `TOF_SUPERSEDED_ARTICLES`;
CREATE TABLE `TOF_SUPERSEDED_ARTICLES` (
  `SUA_ART_ID` int(11) NOT NULL,
  `SUA_CTM` binary(252) NOT NULL,
  `SUA_NUMBER` varchar(66) NOT NULL,
  `SUA_SORT` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SUPPLIERS`
--

DROP TABLE IF EXISTS `TOF_SUPPLIERS`;
CREATE TABLE `TOF_SUPPLIERS` (
  `SUP_ID` smallint(6) NOT NULL,
  `SUP_BRAND` varchar(60) default NULL,
  `SUP_SUPPLIER_NR` smallint(6) default NULL,
  `SUP_COU_ID` smallint(6) default NULL,
  `SUP_IS_HESS` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SUPPLIER_ADDRESSES`
--
-- !!! NOTE: 
-- Original:  `SAD_COU_ID` smallint(6) NOT NULL default '0',
-- Changed to:`SAD_COU_ID` smallint(6) default '0',
--  
DROP TABLE IF EXISTS `TOF_SUPPLIER_ADDRESSES`;
CREATE TABLE `TOF_SUPPLIER_ADDRESSES` (
  `SAD_SUP_ID` smallint(6) NOT NULL,
  `SAD_TYPE_OF_ADDRESS` varchar(9) NOT NULL,
  `SAD_COU_ID` smallint(6) default '0',
  `SAD_NAME1` varchar(120) default NULL,
  `SAD_NAME2` varchar(120) default NULL,
  `SAD_STREET1` varchar(120) default NULL,
  `SAD_STREET2` varchar(120) default NULL,
  `SAD_POB` varchar(30) default NULL,
  `SAD_COU_ID_POSTAL` smallint(6) default NULL,
  `SAD_POSTAL_CODE_PLACE` varchar(24) default NULL,
  `SAD_POSTAL_CODE_POB` varchar(24) default NULL,
  `SAD_POSTAL_CODE_CUST` varchar(24) default NULL,
  `SAD_CITY1` varchar(120) default NULL,
  `SAD_CITY2` varchar(120) default NULL,
  `SAD_TEL` varchar(120) default NULL,
  `SAD_FAX` varchar(60) default NULL,
  `SAD_EMAIL` varchar(180) default NULL,
  `SAD_WEB` varchar(180) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `SUPPLIER_LOGOS`
--
-- !!! NOTE: Graphics file. LOGOS

-- DROP TABLE IF EXISTS `TOF_SUPPLIER_LOGOS`;
-- CREATE TABLE `TOF_SUPPLIER_LOGOS` (
--   `SLO_ID` smallint(6) NOT NULL default '0',
--   `SLO_SUP_ID` smallint(6) NOT NULL,
--   `SLO_CTM` binary(252) NOT NULL,
--   `SLO_LNG_ID` smallint(6) NOT NULL
-- ) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TEXT_MODULES`
--

DROP TABLE IF EXISTS `TOF_TEXT_MODULES`;
CREATE TABLE `TOF_TEXT_MODULES` (
  `TMO_ID` int(11) NOT NULL,
  `TMO_LNG_ID` smallint(6) NOT NULL,
  `TMO_FIXED` smallint(6) NOT NULL,
  `TMO_TMT_ID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TEXT_MODULE_TEXTS`
--

DROP TABLE IF EXISTS `TOF_TEXT_MODULE_TEXTS`;
CREATE TABLE `TOF_TEXT_MODULE_TEXTS` (
  `TMT_ID` int(11) NOT NULL default '0',
  `TMT_TEXT` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYPES`
--

DROP TABLE IF EXISTS `TOF_TYPES`;
CREATE TABLE `TOF_TYPES` (
  `TYP_ID` int(11) NOT NULL,
  `TYP_CDS_ID` int(11) default NULL,
  `TYP_MMT_CDS_ID` int(11) default NULL,
  `TYP_MOD_ID` int(11) NOT NULL,
  `TYP_CTM` binary(252) default NULL,
  `TYP_LA_CTM` binary(252) default NULL,
  `TYP_SORT` int(11) NOT NULL,
  `TYP_PCON_START` int(11) default NULL,
  `TYP_PCON_END` int(11) default NULL,
  `TYP_KW_FROM` int(11) default NULL,
  `TYP_KW_UPTO` int(11) default NULL,
  `TYP_HP_FROM` int(11) default NULL,
  `TYP_HP_UPTO` int(11) default NULL,
  `TYP_CCM` int(11) default NULL,
  `TYP_CYLINDERS` smallint(6) default NULL,
  `TYP_DOORS` smallint(6) default NULL,
  `TYP_TANK` smallint(6) default NULL,
  `TYP_KV_VOLTAGE_DES_ID` int(11) default NULL,
  `TYP_KV_ABS_DES_ID` int(11) default NULL,
  `TYP_KV_ASR_DES_ID` int(11) default NULL,
  `TYP_KV_ENGINE_DES_ID` int(11) default NULL,
  `TYP_KV_BRAKE_TYPE_DES_ID` int(11) default NULL,
  `TYP_KV_BRAKE_SYST_DES_ID` int(11) default NULL,
  `TYP_KV_FUEL_DES_ID` int(11) default NULL,
  `TYP_KV_CATALYST_DES_ID` int(11) default NULL,
  `TYP_KV_BODY_DES_ID` int(11) default NULL,
  `TYP_KV_STEERING_DES_ID` int(11) default NULL,
  `TYP_KV_STEERING_SIDE_DES_ID` int(11) default NULL,
  `TYP_MAX_WEIGHT` double default NULL,
  `TYP_KV_MODEL_DES_ID` int(11) default NULL,
  `TYP_KV_AXLE_DES_ID` int(11) default NULL,
  `TYP_CCM_TAX` int(11) default NULL,
  `TYP_LITRES` double default NULL,
  `TYP_KV_DRIVE_DES_ID` int(11) default NULL,
  `TYP_KV_TRANS_DES_ID` int(11) default NULL,
  `TYP_KV_FUEL_SUPPLY_DES_ID` int(11) default NULL,
  `TYP_VALVES` smallint(6) default NULL,
  `TYP_RT_EXISTS` smallint(6) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYPE_NUMBERS`
--
-- !!! NOTE
-- Original:   `TYN_GOP_NR` varchar(75) NOT NULL default '',
--             `TYN_GOP_START` int(11) NOT NULL default '0'
-- Changed to: `TYN_GOP_NR` varchar(75) default '',
--             `TYN_GOP_START` int(11) default '0'

DROP TABLE IF EXISTS `TOF_TYPE_NUMBERS`;
CREATE TABLE `TOF_TYPE_NUMBERS` (
  `TYN_TYP_ID` int(11) NOT NULL,
  `TYN_SEARCH_TEXT` varchar(60) NOT NULL,
  `TYN_KIND` smallint(6) NOT NULL,
  `TYN_DISPLAY_NR` varchar(60) NOT NULL default '',
  `TYN_CTM` binary(252) default NULL,
  `TYN_GOP_NR` varchar(75) default '',
  `TYN_GOP_START` int(11) default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYP_COUNTRY_SPECIFICS`
--

DROP TABLE IF EXISTS `TOF_TYP_COUNTRY_SPECIFICS`;
CREATE TABLE `TOF_TYP_COUNTRY_SPECIFICS` (
  `TYC_TYP_ID` int(11) NOT NULL,
  `TYC_COU_ID` smallint(6) NOT NULL,
  `TYC_PCON_START` int(11) default NULL,
  `TYC_PCON_END` int(11) default NULL,
  `TYC_KW_FROM` int(11) default NULL,
  `TYC_KW_UPTO` int(11) default NULL,
  `TYC_HP_FROM` int(11) default NULL,
  `TYC_HP_UPTO` int(11) default NULL,
  `TYC_CCM` int(11) default NULL,
  `TYC_CYLINDERS` smallint(6) default NULL,
  `TYC_DOORS` smallint(6) default NULL,
  `TYC_TANK` smallint(6) default NULL,
  `TYC_KV_VOLTAGE_DES_ID` int(11) default NULL,
  `TYC_KV_ABS_DES_ID` int(11) default NULL,
  `TYC_KV_ASR_DES_ID` int(11) default NULL,
  `TYC_KV_ENGINE_DES_ID` int(11) default NULL,
  `TYC_KV_BRAKE_TYPE_DES_ID` int(11) default NULL,
  `TYC_KV_BRAKE_SYST_DES_ID` int(11) default NULL,
  `TYC_KV_CATALYST_DES_ID` int(11) default NULL,
  `TYC_KV_BODY_DES_ID` int(11) default NULL,
  `TYC_KV_STEERING_DES_ID` int(11) default NULL,
  `TYC_KV_STEERING_SIDE_DES_ID` int(11) default NULL,
  `TYC_MAX_WEIGHT` double default NULL,
  `TYC_KV_MODEL_DES_ID` int(11) default NULL,
  `TYC_KV_AXLE_DES_ID` int(11) default NULL,
  `TYC_CCM_TAX` int(11) default NULL,
  `TYC_LITRES` double default NULL,
  `TYC_KV_DRIVE_DES_ID` int(11) default NULL,
  `TYC_KV_TRANS_DES_ID` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYP_SUSPENSIONS`
--

DROP TABLE IF EXISTS `TOF_TYP_SUSPENSIONS`;
CREATE TABLE `TOF_TYP_SUSPENSIONS` (
  `TSU_TYP_ID` int(11) NOT NULL,
  `TSU_NR` smallint(6) NOT NULL,
  `TSU_KV_SUSPENSION_DES_ID` int(11) NOT NULL,
  `TSU_KV_AXLE_POS_DES_ID` int(11) NOT NULL,
  `TSU_CTM` binary(252) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYP_VOLTAGES`
--

DROP TABLE IF EXISTS `TOF_TYP_VOLTAGES`;
CREATE TABLE `TOF_TYP_VOLTAGES` (
  `TVO_TYP_ID` int(11) NOT NULL,
  `TVO_NR` smallint(6) NOT NULL,
  `TVO_KV_VOLTAGE_DES_ID` int(11) NOT NULL,
  `TVO_CTM` binary(252) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `TYP_WHEEL_BASES`
--

DROP TABLE IF EXISTS `TOF_TYP_WHEEL_BASES`;
CREATE TABLE `TOF_TYP_WHEEL_BASES` (
  `TWB_TYP_ID` int(11) NOT NULL,
  `TWB_NR` smallint(6) NOT NULL,
  `TWB_WHEEL_BASE` int(11) NOT NULL,
  `TWB_KV_AXLE_POS_DES_ID` int(11) NOT NULL,
  `TWB_CTM` binary(252) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Table structure for table `UTILITY_DIRECT`
--

DROP TABLE IF EXISTS `TOF_UTILITY_DIRECT`;
CREATE TABLE `TOF_UTILITY_DIRECT` (
  `UTD_ART_ID` int(11) NOT NULL,
  `UTD_CTM` binary(252) NOT NULL,
  `UTD_TEXT` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-06-08  3:44:38
