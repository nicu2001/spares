<?php
function ansi2oem( $str ) { return iconv('CP1251', 'CP866', $str ); }
function utf2oem( $str ) { return iconv('UTF-8', 'CP866', $str ); }

$idb_serv = "tabl.mysql.ukraine.com.ua";
$idb_name = "tabl_slava";
$idb_user = "tabl_slava";
$idb_pass = "val32567";

$odb_serv = "10.194.241.10";
$odb_name = "test";
$odb_user = "vlad";
$odb_pass = "091861";

$owner_id = 1001;

function str_canonify( $istr ) {
	$astr = str_split( strtolower( $istr ) );
	$ostr = "";
	foreach( $astr as $c ) {
		if( ( $c >= '0' && $c <= '9' ) || ( $c >= 'a' && $c <= 'z' ) )
			$ostr .= $c;
	}
	return $ostr;
}

function mysqlConnect($serv, $user, $pass, $db, $charset="utf8") {
	try {
		$idb = new PDO("mysql:host=".$serv.";dbname=".$db.";charset=".$charset, $user,$pass);
	} catch (PDOException $e) {
		die( "DataBase connection to ".$db."@".$serv." failed: ".$e->getMessage() );
	}
return $idb;
}

function DoImport( $idb, $odb, $owner ) {
	$istm = $idb->prepare("select * from pages");
	$istm->execute();
	
	$req =  "INSERT INTO `stock_new` ( owner_id, stock_id, sup_brand, art_nr, price, store ) ".
			"VALUES ( ?, ?, ?, ?, ?, ? )";
			
	$ostm = $odb->prepare( $req );
	
	while( $row = $istm->fetch(PDO::FETCH_ASSOC) ) {
		$stock_id = str_canonify( $row['sup_brand'] ).str_canonify( $row['art_nr'] );
//		echo $stock_id."\t".$row['sup_brand']."\t".$row['art_nr']."\n";	
		$ostm->execute( array( $owner, $stock_id, $row['sup_brand'], $row['art_nr'], 
								$row['cena'], $row['store'] ) );
	}
	$istm->closeCursor();
}

$idb = mysqlConnect( $idb_serv, $idb_user, $idb_pass, $idb_name );
$odb = mysqlConnect( $odb_serv, $odb_user, $odb_pass, $odb_name );

DoImport( $idb, $odb, $owner_id );

?>
