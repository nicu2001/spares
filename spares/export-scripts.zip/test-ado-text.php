<?php
// Экспорт одной таблицы базы данных
// Сделан на основе export-my-stp.php

require_once("ado.inc.php");

class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $odbc_dsn = "MYTECDOC";
var $odbc_id = "";
var $odb = "";

function odbcConnect() {
	$this->odbc_id = ado_connect($this->odbc_dsn);
}

function exportFromTransbase($table_name) {
	$new_table_name = $table_name."_new";
	print Tools::utf2oem(str_pad($table_name, 32) )."\n";

//	$odbc_query = "SELECT * FROM " . $table_name;
	$odbc_query = "select * from tof_des_texts where tex_id in (873587,875585,879500,884090,887114)";

	$data = ado_query($this->odbc_id, $odbc_query);

	$fcount = ado_num_fields($data);
	for( $k=0; $k<$fcount; $k++ ) { 
		$fnames[] = ado_field_name($data, $k);
		$qstm[] = '?'; 
	}

	while( ($values = ado_fetch_row($data)) )
	{
	    echo Tools::ansi2oem(implode( "\t", $values ))."\n";
		unset($values);

	}
	ado_free_result($data);
	
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->odbcConnect(); //Коннект к базе Transbase

$tecdoc->exportFromTransbase("tof_des_texts");
?>
