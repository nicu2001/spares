<?php

class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $mysql_serv = "localhost";
var $mysql_login = "root";
var $mysql_pass = "";
var $mysql_db = "test";
var $tecdoc_dsn = "MYTECDOC";
var $tecdoc_login = "tecdoc";
var $tecdoc_pass = "tcd_error_0";
var $idb = "";
var $odb = "";

const DEBUG = false;
const DEBUG_MAX = 100;

function tecdocConnect() {
	$this->idb = new PDO("odbc:".$this->tecdoc_dsn, $this->tecdoc_login,$this->tecdoc_pass);
}

function exportFromTransbase($table_name) {

	$req = "select tex_id, tex_text from tof_des_texts where tex_id in (873587,875585,879500,884090,887114)";

	$isth = $this->idb->prepare($req);
	if( ! $isth ) die( "odbc prepare statement\n");

	if( ! $isth->execute() ) die( "odbc excute statement\n");
	
	$fcount = $isth->columnCount();
	$isth->bindColumn(1, $id );
	$isth->bindColumn(2, $text, PDO::PARAM_LOB );
	
	while( $row = $isth->fetch(PDO::FETCH_BOUND) )
	{
//		var_dump( $isth->errorInfo() );
		echo Tools::ansi2oem($text."\t");
		echo "\n";
	}
	$isth->closeCursor();
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->tecdocConnect(); //Коннект к базе Transbase

$tecdoc->exportFromTransbase("tof_des_texts");
?>
