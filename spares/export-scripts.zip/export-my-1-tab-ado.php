<?php
// Экспорт одной таблицы базы данных
// Сделан на основе export-my-stp.php

require_once("ado.inc.php");

class Tools {
static function ansi2oem( $str ) { 
	return iconv('CP1251', 'CP866', $str ); 
}
static function utf2oem( $str ) { 
	return iconv('UTF-8', 'CP866', $str ); 
}
} // End of Tools

class Tecdoc {
var $mysql_serv = "localhost";
var $mysql_login = "root";
var $mysql_pass = "";
var $mysql_db = "tecdoc";
var $odbc_dsn = "MYTECDOC";
var $odbc_id = "";
var $odb = "";

const DEBUG = false;
const DEBUG_MAX = 100;

function odbcConnect() {
	$this->odbc_id = ado_connect($this->odbc_dsn);
}

function mysqlConnect() {
// charset=CP1251 - Windows, charset=utf8 - Unix 
	$this->odb = new PDO("mysql:host=".$this->mysql_serv.";dbname=".$this->mysql_db.";charset=CP1251",
							$this->mysql_login,$this->mysql_pass);
}

function exportFromTransbase($table_name) {
	$new_table_name = $table_name;
	print Tools::utf2oem(str_pad($table_name, 32) );

	$odbc_query = "SELECT * FROM " . $table_name;
//	$odbc_query = "select * from tof_des_texts where tex_id in (873587,875585,879500,884090,887114)";

	$data = ado_query($this->odbc_id, $odbc_query);

	$fcount = ado_num_fields($data);
	for( $k=0; $k<$fcount; $k++ ) { 
		$fnames[] = ado_field_name($data, $k);
		$qstm[] = '?'; 
	}

	$mysql_query = "INSERT INTO `".$new_table_name."` (".implode(",", $fnames).") VALUES (".implode(",", $qstm ).")";
	$prep = $this->odb->prepare( $mysql_query );
	if( $prep === false ) {
		die("Prepare statement. Table:".$new_table_name."\n");
	}
	
	$i = 1;
	
// Tag: 01
	$this->odb->exec("LOCK TABLES ".$new_table_name." WRITE");
	while( ($values = ado_fetch_row($data)) )
	{
//	    echo Tools::ansi2oem(implode( "\t", $values ))."\n";
		
		if( $prep->execute($values) === false ) {
			$this->odb->exec("UNLOCK TABLES");
			die( "Error. Record: ".$i."\n" );
		}
		
		set_time_limit(3600);
		unset($values);

		$i++;
		if( self::DEBUG  && $i > self::DEBUG_MAX ) break;
	}
	ado_free_result($data);
	
	echo ($i-1)."\n";
	$this->odb->exec("UNLOCK TABLES");
}

} //End Class

$tecdoc = new Tecdoc();
$tecdoc->odbcConnect(); //Коннект к базе Transbase
$tecdoc->mysqlConnect(); //Коннект к базе MySQL

$tecdoc->exportFromTransbase("tof_des_texts");
?>
